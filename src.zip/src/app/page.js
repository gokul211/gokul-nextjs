// app/page.js
export default function HomePage() {
  return (
    <div>
      <h1>Welcome Home</h1>
      <p>This is the main content area.</p>
    </div>
  );
}
